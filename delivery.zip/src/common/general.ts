// src/common/general.ts

